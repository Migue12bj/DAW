using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using prestasmosApi.Models;

namespace prestasmosApi.Controllers
{
    [ApiController] 
    public class estado_equiposController : ControllerBase
    {
        private readonly prestamosContext _contexto;

        public estado_equiposController(prestamosContext miContexto) {
            this._contexto = miContexto;
        }

        [HttpGet]
        [Route("api/estado_equipos")]
        public IActionResult Get(){
            var estado_equiposList = _contexto.estado_equipos;
            if(estado_equiposList.Count>0){
                return Ok(estado_equiposList);
            }
            return NotFound();            
        } 

    }
}