using System;
using System.ComponentModel.DataAnnotations;
namespace prestasmosApi.Models
{
    public class Estados_equipos
    {
        [Key]
        public int id_estados_equipo { get; set; }
        public string descripcion { get; set; }
        public string estado { get; set; }        
    }
}